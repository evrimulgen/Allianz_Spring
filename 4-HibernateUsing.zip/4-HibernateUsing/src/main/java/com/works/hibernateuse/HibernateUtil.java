package com.works.hibernateuse;

import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class HibernateUtil {

	private static final SessionFactory sessionFactory = build();
	private static SessionFactory build() {
		
		try {
			StandardServiceRegistry req = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
			Metadata meta = new MetadataSources(req).getMetadataBuilder().build();
			return meta.getSessionFactoryBuilder().build();
		} catch (Exception e) {
			System.err.println("Connect Error: " + e);
		}
		return null;
	}
	
	public static SessionFactory getSession() {
		return sessionFactory;
	}
	
}

