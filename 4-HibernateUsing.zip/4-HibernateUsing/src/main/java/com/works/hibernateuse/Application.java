package com.works.hibernateuse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import model.Product;

@SpringBootApplication
public class Application {
	
	SessionFactory sf = HibernateUtil.getSession();

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		//Application ap = new Application();
		//ap.insert();
	}

	
	void insert() {
		
		Session sesi = sf.openSession();
		Transaction tr = sesi.beginTransaction();
		
		Product pr = new Product();
		pr.setTitle("Buzdolabı");
		pr.setDetail("Ürün Detayı");
		pr.setPrice(3000);
		
		sesi.save(pr);
		tr.commit();
	}
	
}
