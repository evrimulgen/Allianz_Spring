package com.works.hibernateuse;

import java.util.HashMap;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import model.Product;

@RestController
public class ProRestController {
	
	SessionFactory sf = HibernateUtil.getSession();
	
	// all product rest
	@GetMapping(value = "/allList")
	public HashMap<String, Object> allList() {
		
		HashMap<String, Object> hm = new HashMap<>();
		Session sesi = sf.openSession();
		List<Product> ls = sesi.createQuery("from Product").getResultList();
		hm.put("products", ls);
		return hm;
	}
	
	
	@PostMapping(value = "/insert")
	public HashMap<String, Object> insert(Product pr) {
		HashMap<String, Object> hm = new HashMap<>();
		
		Session sesi = sf.openSession();
		Transaction tr = sesi.beginTransaction();
		int id = (int) sesi.save(pr);
		tr.commit();
		
		if(id > 0) {
			hm.put("statu", true);
			hm.put("id", id);
		}else {
			hm.put("statu", false);
		}
		
		return hm;
	} 
	
	
	@GetMapping(value = "/search")
	public HashMap<String, Object> search( @RequestParam String q) {
		HashMap<String, Object> hm = new HashMap<>();
		Session sesi = sf.openSession();
		List<Product> ls = sesi.createQuery("from Product where title like ?1 ").setParameter(1, "%"+q+"%").getResultList();
		hm.put("products", ls);
		return hm;
	} 
	
	
	
	
	

}
