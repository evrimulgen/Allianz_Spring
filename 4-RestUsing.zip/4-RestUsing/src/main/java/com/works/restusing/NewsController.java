package com.works.restusing;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import model.Article;
import model.JsonData;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

@Controller
public class NewsController {
	
	@GetMapping("/")
	public String news(Model model) {
		
		Services servis = API.getClient().create(Services.class);
		Call<JsonData> dt = servis.news();
		try {
			List<Article> ls = dt.execute().body().getArticles();
			model.addAttribute("ls", ls);
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		/*
		dt.enqueue(new Callback<JsonData>() {
			
			@Override
			public void onResponse(Call<JsonData> call, Response<JsonData> response) {
				//for (Article item : response.body().getArticles()) {
					//System.out.println(item.getTitle());
				//}
				List<Article> ls = response.body().getArticles();
				model.addAttribute("ls", ls);
			}
			
			@Override
			public void onFailure(Call<JsonData> call, Throwable t) {
				// TODO Auto-generated method stub
				
			}
		});
		*/
		
		
		return "news";
	}

}
