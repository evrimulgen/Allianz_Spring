package com.works.restusing;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Proxy.Type;

import org.springframework.context.annotation.Bean;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;

import model.Todo;

enum pages {
	product
}


@Controller
public class ProductController {
	
	@GetMapping("/product")
	public String product() {
		
		String url = "https://jsonplaceholder.typicode.com/todos/1";
		//Map<String, String> mp = new HashMap<String, String>();
		//mp.put("ref", "5380f5dbcc3b1021f93ab24c3a1aac24");
		//mp.put("start", "0");
		
		RestTemplate rt = new RestTemplate();
		Todo td = rt.getForObject(url, Todo.class);
		System.out.println(td.getTitle());
		
		return pages.product.toString();
	}
	
	
	
	@Bean
	public RestTemplate restTemplate() {
	    SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
	    Proxy proxy = new Proxy(Type.HTTP, new InetSocketAddress("195.87.49.10", 8080));
	    requestFactory.setProxy(proxy);
	    return new RestTemplate(requestFactory);
	}
	

}
