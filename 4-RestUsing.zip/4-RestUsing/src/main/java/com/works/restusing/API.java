package com.works.restusing;

import java.net.InetSocketAddress;
import java.net.Proxy;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class API {
    private static Retrofit retrofit = null;

    public static Retrofit getClient() {
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        //Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("195.87.49.10", 8080));
        //OkHttpClient.Builder httpClient = new OkHttpClient.Builder().proxy(proxy);
        
        httpClient.addInterceptor(logging);
        

        if (retrofit != null) {
            retrofit = null;
        }

        retrofit = new Retrofit.Builder()
                .baseUrl("https://newsapi.org/v2/")
                .addConverterFactory(GsonConverterFactory.create())
                .client(httpClient.build())
                .build();

        return retrofit;
    }
}

