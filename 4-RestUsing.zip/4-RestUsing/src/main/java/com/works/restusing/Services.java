package com.works.restusing;

import model.JsonData;
import retrofit2.Call;
import retrofit2.http.GET;

public interface Services {
	
	@GET("top-headlines?country=tr&apiKey=38a9e086f10b445faabb4461c4aa71f8")
	Call<JsonData> news();
}
