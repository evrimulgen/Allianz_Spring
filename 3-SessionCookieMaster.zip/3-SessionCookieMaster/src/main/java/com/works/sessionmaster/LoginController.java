package com.works.sessionmaster;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {
	
	@Autowired Connection dbSource;
	
	@GetMapping(value = "/login")
	public String login(HttpServletRequest req) {
		boolean statu = req.getSession().getAttribute("user") != null;
		if(statu) {
			return "redirect:/";
		}
		return "login";
	}
	
	
	// user login post
	@PostMapping(value = "/login")
	public String login(@RequestParam String mail, 
			@RequestParam String pass, 
			HttpServletRequest req,
			HttpServletResponse res,
			@RequestParam(defaultValue = "off") String remember_me) {
		try {
			String query = "select * from user where mail = ? and pass = ?";
			PreparedStatement pre = dbSource.prepareStatement(query);
			pre.setString(1, mail);
			pre.setString(2, Util.MD5(pass));
			ResultSet rs = pre.executeQuery();
			if(rs.next()) {
				// user login
				// create session
				req.getSession().setAttribute("user", rs.getInt(1));
				//System.out.println("remember_me : " + remember_me);
				if(remember_me.equals("on")) {
					Cookie cookie = new Cookie("user_cookie", Util.sifrele(""+ rs.getInt(1), 3) );
					cookie.setMaxAge(60);
					res.addCookie(cookie);
				}
				return "redirect:/";
			}else {
				// user login fail
				return "login";
			}
		} catch (Exception e) {
			System.err.println("login error : " + e);
		}
		return "login";
	}
	
	
	// logout
	@GetMapping(value = "/logout")
	public String logout(HttpServletRequest req, HttpServletResponse res) {
		
		// cookie delete
		Cookie cookie = new Cookie("user_cookie", "");
		cookie.setMaxAge(0);
		res.addCookie(cookie);
		
		req.getSession().removeAttribute("user");
		req.getSession().invalidate(); // all session delete
		return "redirect:/login";
	}
	

}
