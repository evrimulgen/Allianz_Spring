package com.works.sessionmaster;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import props.User;

@Controller
public class FormController {
	
	@Autowired Connection dbSource;
	String pushData = "";
	String error = "";
	User gus = new User();
	
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String form( Model model, HttpServletRequest req) {
		
		model.addAttribute("ls", dataResult());
		model.addAttribute("txtName", pushData);
		if (!error.equals("")) {
			model.addAttribute("error", error);
			model.addAttribute("gus", gus);
			error = "";
		}
		return Util.control(req, "form");
	}
	
	
	@RequestMapping(value = "/userForm", method = RequestMethod.POST)
	public String userForm( User us, Random rd ) {
		pushData = us.getTxtMail();
		if(us.getTxtName().equals("") || us.getTxtMail().equals("") ) {
			error = "Lütfen tüm alanları doldurunuz";
			gus = us;
		}else {
			dataInsert(us);
		}
		return "redirect:/";
	}
	
	
	int dataInsert(User us) {
		int statu = -1;
		try {
			String query = "insert into user values( null, ?, ?, ?, ? )";
			PreparedStatement pre = dbSource.prepareStatement(query);
			pre.setString(1, us.getTxtName());
			pre.setString(2, us.getTxtSurname());
			pre.setString(3, us.getTxtMail());
			pre.setString(4, Util.MD5(us.getTxtPass()));
			statu = pre.executeUpdate();
			gus = new User();
		} catch (Exception e) {
			System.err.println("Insert Fail : " + e);
		}
		return statu;
	}
	
	
	
	// dataResult
	private List<User> dataResult() {
		List<User> ls = new ArrayList<User>();
		
		try {
			String query = "select * from user";
			PreparedStatement pre = dbSource.prepareStatement(query);
			ResultSet rs = pre.executeQuery();
			while(rs.next()) {
				User us = new User();
				us.setUid(rs.getInt(1));
				us.setTxtName(rs.getString("name"));
				us.setTxtSurname(rs.getString("surname"));
				us.setTxtMail(rs.getString("mail"));
				us.setTxtPass(rs.getString("pass"));
				ls.add(us);
			}
		} catch (Exception e) {
			System.err.println("Result Error : " + e);
		}
		
		return ls;
	}
	
	
	// delete item
	@RequestMapping(value = "/delete/{uid}", method = RequestMethod.GET)
	public String deleteItem(@PathVariable int uid) {
		try {
			String query = "delete from user where uid = ?";
			PreparedStatement pre = dbSource.prepareStatement(query);
			 pre.setInt(1, uid);
			 int statu = pre.executeUpdate();
			 if (statu > 0) {
				 return "redirect:/";
			 }else {
				 return "form";
			 }
			
		} catch (Exception e) {
			System.err.println("Delete error : " + e);
		}
		return "redirect:/";
	}
	
	

}
