package com.works.entryy;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HelpController {

	
	
	@RequestMapping(value = "/help/{data}", method = RequestMethod.GET )
	public String help( @PathVariable(value = "data") String xdata, 
			Model model) {
		System.out.println(xdata);
		model.addAttribute("dt", xdata);
		return "help";
	}	
	
}
