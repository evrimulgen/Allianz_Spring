package com.works.entryy;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
//@RequestMapping("/")
public class CallController {
	
	public CallController() {
		System.out.println(" CallController calling ");
	}
	
	ArrayList<String> ls = new ArrayList<>();
		
	@RequestMapping(value = "/call", method = RequestMethod.GET)
	public String call( Model model ) {
		model.addAttribute("dataKey", "DataVal");
		model.addAttribute("data", dataResult());
		System.out.println("call calling");
		return "call";
	}
	
	public ArrayList<String> dataResult() {
		ls.clear();
		for (int i = 0; i < 10; i++) {
			ls.add("Ali : " + i);
		}
		return ls;
	}

}
