package props;

public class User {
	
	private int uid;
	private String txtName;
	private String txtSurname;
	private String txtMail;
	private String txtPass;
	
	
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getTxtPass() {
		return txtPass;
	}
	public void setTxtPass(String txtPass) {
		this.txtPass = txtPass;
	}
	public String getTxtName() {
		return txtName;
	}
	public void setTxtName(String txtName) {
		this.txtName = txtName;
	}
	public String getTxtSurname() {
		return txtSurname;
	}
	public void setTxtSurname(String txtSurname) {
		this.txtSurname = txtSurname;
	}
	public String getTxtMail() {
		return txtMail;
	}
	public void setTxtMail(String txtMail) {
		this.txtMail = txtMail;
	}
	
	
	
}
