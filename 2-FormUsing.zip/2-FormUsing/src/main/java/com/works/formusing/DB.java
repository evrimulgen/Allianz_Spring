package com.works.formusing;

import java.sql.Connection;
import java.sql.DriverManager;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;

@Controller
public class DB {
	
	final private String driver = "com.mysql.jdbc.Driver";
	final private String dbUrl = "jdbc:mysql://localhost/spring?useUnicode=true&characterEncoding=utf-8";
	final private String dbUserName = "root";
	final private String dbUserPass = "";

	@Bean(value = "dbSource")
	public Connection dbConnect() {
		Connection con = null;
		try {
			Class.forName(driver);
			con = DriverManager.getConnection(dbUrl, dbUserName, dbUserPass);
			System.out.println("Connection Success");
		} catch (Exception e) {
			System.err.println("Connection Error : " + e);
		}
		
		return con;
	}
	
	
	
}
