package com.works.restapiusing;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@ComponentScan(value = "com.works.restapiusing")
public class RestConfig {

	@Bean
	public DriverManagerDataSource dataSource() {
		DriverManagerDataSource dt = new DriverManagerDataSource();
		dt.setDriverClassName("com.mysql.cj.jdbc.Driver");
		dt.setUrl("jdbc:mysql://localhost/spring");
		dt.setUsername("root");
		dt.setPassword("");
		return dt;
	}
	
	
}
