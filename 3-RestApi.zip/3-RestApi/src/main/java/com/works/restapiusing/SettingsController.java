package com.works.restapiusing;

import java.util.HashMap;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/user")
public class SettingsController {

	@GetMapping(value = "/single")
	public HashMap<String, Object> us() {
		HashMap<String, Object> hm = new HashMap<>();
		hm.put("name",  "Veli Bilmem");
		return hm;
	}
	
}
