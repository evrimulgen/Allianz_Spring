package com.works.restapiusing;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/admin")
public class UserRestController {

	@Autowired
	DriverManagerDataSource dataSource;

	@GetMapping(value = "/allUser")
	public HashMap<String, Object> allUser(@RequestParam(defaultValue = "") String q, Product pr) {
		System.out.println("Title : " + pr.getTitle());
		HashMap<String, Object> hm = new HashMap<>();
		hm.put("statu", true);
		hm.put("count", 10);
		hm.put("message", "işlem başarılı");
		hm.put("list", dataResult());
		hm.put("result", data());
		return hm;
	}

	public List<Product> dataResult() {
		List<Product> ls = new ArrayList<Product>();
		for (int i = 0; i < 10; i++) {
			Product pr = new Product();
			pr.setPid(i);
			pr.setPrice(i*i);
			pr.setTitle("Title : " + i);
			ls.add(pr);
		}
		return ls;
	}

	
	public List<String> data() 
	{
		List<String> ls = new ArrayList<String>();
		try {
			String query = "select * from user";
			PreparedStatement pre = dataSource.getConnection().prepareStatement(query);
			ResultSet rs = pre.executeQuery();
			while(rs.next()) {
				ls.add(rs.getString("name"));
			}
			return ls;
		} catch (Exception e) {
			System.err.println("error : " + e);
		}
		return null;
	}

	
	

}
