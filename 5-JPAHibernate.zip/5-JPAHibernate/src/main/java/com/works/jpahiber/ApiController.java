package com.works.jpahiber;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.works.jpahiber.model.Note;
import com.works.jpahiber.repository.NoteRepository;

@RestController
@RequestMapping("/api")
public class ApiController {
	
	@Autowired NoteRepository noteRepository;
	
	
	@PostMapping("/note")
	public Note insert( Note note ) {
		return noteRepository.save(note);
	}

}
